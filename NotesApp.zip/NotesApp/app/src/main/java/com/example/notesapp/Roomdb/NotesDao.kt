package com.example.notesapp.Roomdb
import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.notesapp.model.data.NotesDataClass

@Dao
interface NotesDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertData(notes: NotesDataClass)

    @Query("SELECT * FROM notes_table ORDER BY id ASC")
    fun readData():LiveData<List<NotesDataClass>>

    @Delete
    suspend fun deleteData(notes: NotesDataClass)

    @Update
    suspend fun updatedata(notes: NotesDataClass)
}