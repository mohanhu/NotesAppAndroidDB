package com.example.notesapp.Roomdb

import androidx.lifecycle.LiveData
import com.example.notesapp.model.data.NotesDataClass

class NotesRepository(val notesDao: NotesDao) {

    val readData:LiveData<List<NotesDataClass>> = notesDao.readData()

    suspend fun deleteData(notes:NotesDataClass) = notesDao.deleteData(notes)

    suspend fun insertData(notes: NotesDataClass) = notesDao.insertData(notes)

    suspend fun upDateData(notes: NotesDataClass){
         notesDao.updatedata(notes)
    }
}