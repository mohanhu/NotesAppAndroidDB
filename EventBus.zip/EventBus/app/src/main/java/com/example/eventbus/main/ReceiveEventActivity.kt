
package com.example.eventbus.main

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.AttributeSet
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.navigation.Navigation
import androidx.navigation.findNavController
import com.example.eventbus.R
import com.example.eventbus.data.MessageDataClass
import com.example.eventbus.databinding.ActivityReceiveEventBinding
import kotlinx.coroutines.Dispatchers.IO
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import timber.log.Timber

class ReceiveEventActivity : AppCompatActivity() {

    private lateinit var binding: ActivityReceiveEventBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d("responses", "4d")
        binding= ActivityReceiveEventBinding.inflate(layoutInflater)
        setContentView(binding.root)
        try {
            EventBus.getDefault().register( this)
        }catch (e:Exception){
            Timber.d("EventBus Excpetion : ${e.message}")
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageDataClass){
        Log.d("responses", "received")
        Log.d("responses","${event.name}")
    }
    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }
}