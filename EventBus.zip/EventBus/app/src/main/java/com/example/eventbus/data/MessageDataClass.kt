package com.example.eventbus.data

data class MessageDataClass(val name:String?=null,
val age:Int?=null)

