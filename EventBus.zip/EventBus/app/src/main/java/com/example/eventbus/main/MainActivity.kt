package com.example.eventbus.main

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.navigation.Navigation
import com.example.eventbus.R
import com.example.eventbus.data.MessageDataClass
import com.example.eventbus.databinding.ActivityMainBinding
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import timber.log.Timber

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()
        EventBus.getDefault().register(this)

        //incorrect forward move
        binding.save.setOnClickListener {
            val empName = binding.empLame.text.toString()
            val empAge = binding.empAge.text.toString()

            if (empAge.isEmpty() || empName.isEmpty()) {
                Toast.makeText(this, "failed", Toast.LENGTH_SHORT).show()
            } else {
                try {
                    Integer.parseInt(empAge)
                    val user = MessageDataClass(name = empName, age = empAge.toInt())
                    Intent(this, ReceiveEventActivity::class.java).apply {
                        startActivity(this)
                        finish()
                    }
                    EventBus.getDefault().post(user)
                }
                catch (e:Exception){
                    Toast.makeText(this, "failed", Toast.LENGTH_SHORT).show()
                }

            }

        }
    }

  @Subscribe(threadMode = ThreadMode.MAIN)
  fun onMessageReceived(event:MessageDataClass){
     binding.empLame.setText(event.name)
      binding.empAge.setText(event.age.toString())
  }
    override fun onDestroy() {
        super.onDestroy()
    }
}