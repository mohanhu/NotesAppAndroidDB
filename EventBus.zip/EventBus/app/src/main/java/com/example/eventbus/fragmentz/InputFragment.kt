package com.example.eventbus.fragmentz

import android.os.Bundle
import android.os.Message
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.example.eventbus.R
import com.example.eventbus.data.MessageDataClass
import com.example.eventbus.databinding.FragmentInputBinding
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import timber.log.Timber

class InputFragment : Fragment() {
    private lateinit var binding: FragmentInputBinding
    private var empUpdateName: String? = null
    private var empUpdateAge: Int? = null
    private var messagename: String? = null
    private var messageage: String? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentInputBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        registerEventBus()

        binding.first.setOnClickListener {
            findNavController().navigate(R.id.action_inputFragment_to_messageFragment)
        }
        binding.empNamedesc.text = messagename
        binding.empAgedesc.text = messageage
    }

    private fun registerEventBus() {
        try {
            EventBus.getDefault().register(this)
        } catch (e: Exception) {
            Timber.d("EventBus Excpetion : ${e.message}")
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onMessageEvent(event: MessageDataClass) {
        messagename = event.name
        messageage = event.age.toString()
        Log.d("responses", "4ds")
        Log.d("responses", "${event.name}")
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }
}