package com.example.eventbus.fragmentz

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.view.SupportActionModeWrapper
import androidx.lifecycle.lifecycleScope
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import com.example.eventbus.R
import com.example.eventbus.data.MessageDataClass
import com.example.eventbus.databinding.FragmentMessageBinding
import com.example.eventbus.main.ReceiveEventActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import timber.log.Timber


class MessageFragment : Fragment() {
    private lateinit var binding: FragmentMessageBinding
    private var displayVal: String? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentMessageBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.save.setOnClickListener {
            val empName = binding.empLame.text.toString()
            val empAge = binding.empAge.text.toString()

            if (empAge.isEmpty() || empName.isEmpty()) {
                Toast.makeText(requireContext(), "failed", Toast.LENGTH_SHORT).show()
            } else {
                try {
                    Integer.parseInt(empAge)
                    val user = MessageDataClass(name = empName, age = empAge.toInt())
                    EventBus.getDefault().post(user)
                } catch (e: Exception) {
                    Toast.makeText(requireContext(), "failed", Toast.LENGTH_SHORT).show()
                }

            }
          //  findNavController().navigate(R.id.action_messageFragment_to_inputFragment)
        }
    }
}